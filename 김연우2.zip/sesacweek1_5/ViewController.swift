//
//  ViewController.swift
//  sesacweek1_5
//
//  Created by 여누 on 5/19/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

